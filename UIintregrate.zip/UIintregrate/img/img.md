This folder is to be used for storing images. 

Be sure to compress before uploading images for better site performance