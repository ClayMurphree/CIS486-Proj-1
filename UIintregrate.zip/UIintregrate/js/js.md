This folder is to be used for storing scripts.

Minify scripts for improved performance.