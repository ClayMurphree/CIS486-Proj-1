This folder is to be used for the purposes of storing css or scss files.

Minify css for improved performance.